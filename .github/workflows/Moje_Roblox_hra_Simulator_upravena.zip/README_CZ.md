# Moje Roblox hra — Simulator

Upravený prototyp pro Roblox Studio obsahuje:
- **Cash**: hráč získává peníze kliknutím na tlačítko.
- **Vylepšování síly**: každé vylepšení zvyšuje výdělek za klik; cena postupně roste.
- **Obchod**: za 100 Cash lze koupit automatické vydělávání.
- **Automatické vydělávání**: po zakoupení dostane hráč každých 5 sekund částku odpovídající aktuální síle.
- **Ukládání dat**: Cash, síla i vlastnictví automatického vydělávání se ukládají přes DataStore.
- **Serverová kontrola**: peníze, nákupy i automatické odměny počítá server.

## Instalace do Roblox Studia

1. Rozbal ZIP do složky v počítači.
2. V Roblox Studiu vytvoř projekt **Baseplate**.
3. V `ServerScriptService` vlož objekt `Script` a přejmenuj ho na `SimulatorServer`. Zkopíruj obsah souboru `ServerScriptService/SimulatorServer.server.lua`.
4. V `StarterPlayer > StarterPlayerScripts` vlož `LocalScript` a pojmenuj ho `SimulatorClient`. Zkopíruj obsah souboru `StarterPlayer/StarterPlayerScripts/SimulatorClient.client.lua`.
5. Spusť **Play**. Rozhraní hry se zobrazí vlevo.

Serverový skript automaticky vytvoří potřebné RemoteEvents v `ReplicatedStorage`.

## Jak hrát

1. Klikni na **Vydělat peníze** a získávej Cash.
2. Kupuj **Vylepšení síly**, aby každý klik vydělával víc.
3. Jakmile máš 100 Cash, otevři obchod tlačítkem **Obchod: auto výdělek**. Po nákupu dostáváš Cash automaticky každých 5 sekund.

## Zapnutí ukládání

1. Publikuj hru přes `File > Publish to Roblox`.
2. V nastavení hry (`Game Settings > Security`) povol `Enable Studio Access to API Services`, pokud chceš ukládání testovat v Roblox Studiu. Testuj ideálně v samostatné kopii hry.
3. Spusť test znovu a kontroluj `View > Output`, pokud se objeví chyba DataStore.

## Poznámky

- ZIP obsahuje skripty a návod, nikoli hotový publikovaný Roblox place soubor. Skripty je potřeba vložit do Roblox Studia.
- Prototyp používá DataStore `MojeRobloxHra_Simulator_v2`, aby nová verze oddělila ukládaná data od předchozí verze.
- Před veřejným vydáním otestuj ukládání, ceny a hru pro více hráčů.
