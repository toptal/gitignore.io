-- Moje Roblox hra — Simulator
-- Umístění: ServerScriptService > Script
-- Peníze, vylepšování síly, automatické vydělávání, obchod a ukládání dat.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local DataStoreService = game:GetService("DataStoreService")

local STORE = DataStoreService:GetDataStore("MojeRobloxHra_Simulator_v2")
local START_CASH = 0
local START_POWER = 1
local BASE_UPGRADE_COST = 25
local AUTO_INCOME_COST = 100
local COLLECT_COOLDOWN = 0.25
local AUTO_INTERVAL = 5
local SAVE_INTERVAL = 60

local remotes = ReplicatedStorage:FindFirstChild("SimulatorRemotes")
if not remotes then
    remotes = Instance.new("Folder")
    remotes.Name = "SimulatorRemotes"
    remotes.Parent = ReplicatedStorage
end

local function getRemote(name)
    local remote = remotes:FindFirstChild(name)
    if not remote then
        remote = Instance.new("RemoteEvent")
        remote.Name = name
        remote.Parent = remotes
    end
    return remote
end

local CollectRequest = getRemote("CollectRequest")
local UpgradeRequest = getRemote("UpgradeRequest")
local BuyAutoRequest = getRemote("BuyAutoRequest")
local UpdateUI = getRemote("UpdateUI")
local Notify = getRemote("Notify")

local lastCollect = {}
local saving = {}
local loaded = {}

local function upgradeCost(power)
    return math.floor(BASE_UPGRADE_COST * (1.65 ^ math.max(0, power - 1)))
end

local function getValues(player)
    local stats = player:FindFirstChild("leaderstats")
    local cash = stats and stats:FindFirstChild("Cash")
    local power = player:FindFirstChild("Power")
    local autoIncome = player:FindFirstChild("AutoIncome")
    if not cash or not power or not autoIncome then return nil end
    return cash, power, autoIncome
end

local function sendState(player, message)
    local values = {getValues(player)}
    local cash, power, autoIncome = values[1], values[2], values[3]
    if not cash or not power or not autoIncome then return end
    UpdateUI:FireClient(player, {
        cash = cash.Value,
        power = power.Value,
        nextCost = upgradeCost(power.Value),
        collectAmount = power.Value,
        autoIncome = autoIncome.Value,
        autoCost = AUTO_INCOME_COST,
        autoAmount = power.Value,
        autoInterval = AUTO_INTERVAL,
    })
    if message then Notify:FireClient(player, message) end
end

local function savePlayer(player)
    if saving[player] or not loaded[player] then return end
    local cash, power, autoIncome = getValues(player)
    if not cash or not power or not autoIncome then return end
    saving[player] = true
    local data = {cash = cash.Value, power = power.Value, autoIncome = autoIncome.Value}
    local ok, err = pcall(function()
        STORE:UpdateAsync("player_" .. player.UserId, function(oldData)
            -- V tomto jednoduchém single-server prototypu ukládáme aktuální stav hráče.
            return data
        end)
    end)
    if not ok then warn("Uložení dat selhalo pro " .. player.Name .. ": " .. tostring(err)) end
    saving[player] = nil
end

local function loadPlayer(player)
    local data
    local ok, result = pcall(function()
        return STORE:GetAsync("player_" .. player.UserId)
    end)
    if ok and type(result) == "table" then
        data = result
    elseif not ok then
        warn("Načtení dat selhalo pro " .. player.Name .. ": " .. tostring(result))
    end

    local leaderstats = Instance.new("Folder")
    leaderstats.Name = "leaderstats"
    leaderstats.Parent = player

    local cash = Instance.new("IntValue")
    cash.Name = "Cash"
    cash.Value = math.clamp(math.floor(tonumber(data and data.cash) or START_CASH), 0, 2000000000)
    cash.Parent = leaderstats

    local power = Instance.new("IntValue")
    power.Name = "Power"
    power.Value = math.clamp(math.floor(tonumber(data and data.power) or START_POWER), 1, 100000)
    power.Parent = player

    local autoIncome = Instance.new("BoolValue")
    autoIncome.Name = "AutoIncome"
    autoIncome.Value = data and data.autoIncome == true or false
    autoIncome.Parent = player

    loaded[player] = true
    sendState(player, "Vítej ve hře Moje Roblox hra!")
end

Players.PlayerAdded:Connect(loadPlayer)

Players.PlayerRemoving:Connect(function(player)
    savePlayer(player)
    lastCollect[player] = nil
    saving[player] = nil
    loaded[player] = nil
end)

CollectRequest.OnServerEvent:Connect(function(player)
    local now = os.clock()
    if lastCollect[player] and now - lastCollect[player] < COLLECT_COOLDOWN then return end
    lastCollect[player] = now
    local cash, power = getValues(player)
    if not cash or not power then return end
    cash.Value = math.min(2000000000, cash.Value + math.clamp(power.Value, 1, 100000))
    sendState(player)
end)

UpgradeRequest.OnServerEvent:Connect(function(player)
    local cash, power = getValues(player)
    if not cash or not power then return end
    if power.Value >= 100000 then
        sendState(player, "Dosáhl jsi maximální síly.")
        return
    end
    local cost = upgradeCost(power.Value)
    if cash.Value < cost then
        sendState(player, "Ještě nemáš dost peněz. Potřebuješ " .. cost .. " Cash.")
        return
    end
    cash.Value -= cost
    power.Value += 1
    sendState(player, "Síla vylepšena! Za klik získáš " .. power.Value .. " Cash.")
end)

BuyAutoRequest.OnServerEvent:Connect(function(player)
    local cash, _, autoIncome = getValues(player)
    if not cash or not autoIncome then return end
    if autoIncome.Value then
        sendState(player, "Automatické vydělávání už máš koupené.")
        return
    end
    if cash.Value < AUTO_INCOME_COST then
        sendState(player, "Na automatické vydělávání potřebuješ " .. AUTO_INCOME_COST .. " Cash.")
        return
    end
    cash.Value -= AUTO_INCOME_COST
    autoIncome.Value = true
    sendState(player, "Obchod: automatické vydělávání aktivováno!")
end)

-- Automatické vydělávání běží výhradně na serveru, pokud si ho hráč koupil.
task.spawn(function()
    while true do
        task.wait(AUTO_INTERVAL)
        for _, player in ipairs(Players:GetPlayers()) do
            local cash, power, autoIncome = getValues(player)
            if cash and power and autoIncome and autoIncome.Value then
                cash.Value = math.min(2000000000, cash.Value + math.clamp(power.Value, 1, 100000))
                sendState(player, "+" .. tostring(power.Value) .. " Cash z automatického vydělávání.")
            end
        end
    end
end)

task.spawn(function()
    while true do
        task.wait(SAVE_INTERVAL)
        for _, player in ipairs(Players:GetPlayers()) do task.spawn(savePlayer, player) end
    end
end)

game:BindToClose(function()
    local players = Players:GetPlayers()
    local remaining = #players
    if remaining == 0 then return end
    local finished = 0
    for _, player in ipairs(players) do
        task.spawn(function()
            savePlayer(player)
            finished += 1
        end)
    end
    local deadline = os.clock() + 25
    while finished < remaining and os.clock() < deadline do task.wait(0.1) end
end)
