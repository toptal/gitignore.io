-- Moje Roblox hra — Simulator
-- Umístění: StarterPlayer > StarterPlayerScripts > LocalScript
-- Rozhraní: peníze, klikání, vylepšování a obchod s automatickým výdělkem.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local player = Players.LocalPlayer

local remotes = ReplicatedStorage:WaitForChild("SimulatorRemotes")
local CollectRequest = remotes:WaitForChild("CollectRequest")
local UpgradeRequest = remotes:WaitForChild("UpgradeRequest")
local BuyAutoRequest = remotes:WaitForChild("BuyAutoRequest")
local UpdateUI = remotes:WaitForChild("UpdateUI")
local Notify = remotes:WaitForChild("Notify")

local oldGui = player:WaitForChild("PlayerGui"):FindFirstChild("SimulatorGui")
if oldGui then oldGui:Destroy() end

local gui = Instance.new("ScreenGui")
gui.Name = "SimulatorGui"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local panel = Instance.new("Frame")
panel.Name = "MainPanel"
panel.Size = UDim2.new(0, 330, 0, 330)
panel.Position = UDim2.new(0, 18, 0.5, -165)
panel.BackgroundColor3 = Color3.fromRGB(25, 31, 48)
panel.BorderSizePixel = 0
panel.Parent = gui
Instance.new("UICorner", panel).CornerRadius = UDim.new(0, 14)

local padding = Instance.new("UIPadding")
padding.PaddingLeft = UDim.new(0, 12)
padding.PaddingRight = UDim.new(0, 12)
padding.Parent = panel

local function makeLabel(name, text, y, height, fontSize)
    local label = Instance.new("TextLabel")
    label.Name = name
    label.Size = UDim2.new(1, 0, 0, height)
    label.Position = UDim2.new(0, 0, 0, y)
    label.BackgroundTransparency = 1
    label.Text = text
    label.TextColor3 = Color3.fromRGB(255, 255, 255)
    label.Font = Enum.Font.GothamBold
    label.TextSize = fontSize
    label.TextWrapped = true
    label.Parent = panel
    return label
end

makeLabel("Title", "MOJE ROBLOX HRA", 10, 32, 20)
local statsLabel = makeLabel("Stats", "Načítám data…", 45, 48, 16)
local messageLabel = makeLabel("Message", "Klikni a vydělávej!", 93, 34, 12)
messageLabel.TextColor3 = Color3.fromRGB(170, 210, 255)

local function makeButton(name, text, y, color)
    local button = Instance.new("TextButton")
    button.Name = name
    button.Size = UDim2.new(1, 0, 0, 48)
    button.Position = UDim2.new(0, 0, 0, y)
    button.BackgroundColor3 = color
    button.BorderSizePixel = 0
    button.Text = text
    button.TextColor3 = Color3.fromRGB(255, 255, 255)
    button.Font = Enum.Font.GothamBold
    button.TextSize = 15
    button.TextWrapped = true
    button.AutoButtonColor = true
    button.Parent = panel
    Instance.new("UICorner", button).CornerRadius = UDim.new(0, 10)
    return button
end

local collectButton = makeButton("CollectButton", "VYDĚLAT PENÍZE", 132, Color3.fromRGB(32, 145, 90))
local upgradeButton = makeButton("UpgradeButton", "VYLEPŠIT SÍLU", 188, Color3.fromRGB(63, 105, 210))
local shopButton = makeButton("ShopAutoButton", "OBCHOD: AUTOMATICKÝ VÝDĚLEK", 244, Color3.fromRGB(155, 95, 35))

collectButton.Activated:Connect(function() CollectRequest:FireServer() end)
upgradeButton.Activated:Connect(function() UpgradeRequest:FireServer() end)
shopButton.Activated:Connect(function() BuyAutoRequest:FireServer() end)

UpdateUI.OnClientEvent:Connect(function(state)
    if type(state) ~= "table" then return end
    statsLabel.Text = "Cash: " .. tostring(state.cash) .. "   |   Síla: " .. tostring(state.power)
    collectButton.Text = "VYDĚLAT +" .. tostring(state.collectAmount or state.power) .. " CASH"
    upgradeButton.Text = "VYLEPŠIT SÍLU — " .. tostring(state.nextCost) .. " CASH"
    if state.autoIncome then
        shopButton.Text = "AUTOMATICKY +" .. tostring(state.autoAmount or state.power) .. " CASH / 5 S"
        shopButton.BackgroundColor3 = Color3.fromRGB(32, 120, 135)
    else
        shopButton.Text = "OBCHOD: AUTO VÝDĚLEK — " .. tostring(state.autoCost or 100) .. " CASH"
        shopButton.BackgroundColor3 = Color3.fromRGB(155, 95, 35)
    end
end)

Notify.OnClientEvent:Connect(function(message)
    if type(message) == "string" then messageLabel.Text = message end
end)
